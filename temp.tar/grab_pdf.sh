#!/bin/bash

scp ggian@clone2.cslab.ece.ntua.gr:/local/ggian/matching/current.pdf ./
